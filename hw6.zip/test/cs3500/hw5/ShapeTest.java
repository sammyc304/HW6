package cs3500.hw5;
/*
import org.junit.Test;

import static org.junit.Assert.assertEquals;

import java.awt.Color;
import java.util.ArrayList;

import cs3500.model.*;
*/


/**
 * Class to test Shape.
 */
public class ShapeTest {
  /*private Position position1 = new Position();
  private Dimension dimension1 = new Dimension();
  private Shape testShapeCircle = new Shape("testShape1Circle", 1,
      position1, dimension1, Color.GREEN, ShapeType.OVAL);

  @Test
  public void testGetLog() {
    ArrayList<ShapeState> temp = new ArrayList<>();
    temp.add(new ShapeState(1, position1, dimension1, Color.GREEN));
    assertEquals(temp.get(0), testShapeCircle.getLog().get(0));

  }

  @Test
  public void testSetNewState() {
    Position position2 = new Position();
    Dimension dimension2 = new Dimension();
    ShapeState tempShapeState = new ShapeState(2, position2, dimension2, Color.BLACK);
    testShapeCircle.setNewState(2, position2, dimension2, Color.BLACK);
    assertEquals(testShapeCircle.getLog().get(1), tempShapeState);
  }

  @Test
  public void testGetShapeType() {
    assertEquals(testShapeCircle.getShapeType(), ShapeType.OVAL);
  }

  @Test
  public void testGetName() {
    assertEquals(testShapeCircle.getName(), ShapeType.OVAL);
  }*/


}
